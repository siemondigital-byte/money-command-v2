/* global React, DesignCanvas, DCSection, DCArtboard */
// The Money Command — Hero variants for Fase 2 A/B test (Variante B fintech terminal)
// 5 directions × 2 languages = 10 artboards inside <DesignCanvas>

const { useState } = React;

/* ── Tweaks: scale + cyan play ──────────────────────────────── */
const TWEAK_DEFAULTS = /*EDITMODE-BEGIN*/{
  "numScale": 0.82,
  "headScale": 0.86,
  "highlight": "Cyan",
  "numberColor": "Mint",
  "cyanGlow": 0.12
}/*EDITMODE-END*/;

// Big-number + headline sizes are authored at full size, then scaled by a
// CSS var so the Tweaks panel can dial them down without touching every value.
const numS  = (px) => `calc(${px}px * var(--num-scale, 0.82))`;
const headS = (px) => `calc(${px}px * var(--head-scale, 0.86))`;

/* ─────────────────────────────────────────────────────────────
   COPY · ES + EN per direction
   Anchored to the master brief — frases ancla protegidas literally.
───────────────────────────────────────────────────────────── */

const COPY = {
  brand: 'The Money Command',
  founders: { es: 'Founders Cohort · 153 / 500 sold', en: 'Founders Cohort · 153 / 500 sold' },
  liveTag: { es: 'Live · 2026.05', en: 'Live · 2026.05' },
  disclaimer: { es: 'Contenido educativo · No asesoría financiera · Divine Cosmic Lite, LLC',
                en: 'Educational content · Not financial advice · Divine Cosmic Lite, LLC' },
  founderCounter: { es: 'Quedan 347 plazas · Lifetime app incluida',
                    en: '347 seats remain · Lifetime app included' },
  primaryCta: { es: 'Quiero The Money Command — USD 39',
                en: 'I want The Money Command — USD 39' },
  secondaryCta: { es: 'Empieza gratis con la Calculadora',
                  en: 'Start free with the Calculator' },
  founderCap: { es: 'Precio de fundadores', en: 'Founders pricing' },
  regularCap: { es: 'Primeros 500 alumnos', en: 'First 500 students' },
  regularLabel: { es: 'Regular · post-lanzamiento', en: 'Regular · post-launch' },
};

const A = {
  pill: { es: 'Viven paycheck-to-paycheck', en: 'Living paycheck-to-paycheck' },
  body: {
    es: <>De quienes ganan <span className="mint">+100K USD</span>, viven al día.<br/>Estadísticamente, eres uno.</>,
    en: <>Of those earning <span className="mint">+100K USD</span>, live day-to-day.<br/>Statistically, you are one.</>,
  },
  subtitle: {
    es: 'Mentalidad y aritmética para manifestar tu libertad financiera.',
    en: 'Mindset and arithmetic to design your financial freedom.',
  },
  source: { es: 'Source — Bank of America Institute · Edelman 2025',
            en: 'Source — Bank of America Institute · Edelman 2025' },
};

const B = {
  pill: { es: 'The Money Command App · incluida', en: 'The Money Command App · included' },
  headlineA: { es: 'Cuenta de ejecutivo.', en: 'Executive account.' },
  headlineB: { es: 'Saldo de becario.', en: 'Intern balance.' },
  subtitle: {
    es: 'El dashboard que opera el método del libro. Monarch USD 99/año. YNAB USD 109/año. Money Command: incluida.',
    en: 'The dashboard that runs the book\u2019s method. Monarch $99/yr. YNAB $109/yr. Money Command: included.',
  },
  chipA: { es: '×4.04 tu inversión', en: '×4.04 your investment' },
  chipB: { es: 'CAGR 7%', en: 'CAGR 7%' },
  chipC: { es: 'Lifetime · primeros 500', en: 'Lifetime · first 500' },
};

const C = {
  pill: { es: 'Financial Calculator · en vivo', en: 'Financial Calculator · live' },
  headlineA: { es: 'Tu libertad financiera tiene un número.', en: 'Your financial freedom has a number.' },
  headlineB: { es: 'Aquí está.', en: 'Here it is.' },
  subtitle: {
    es: 'Mové los sliders. La calculadora te dice cuánto necesitas y cuántos años faltan a tu ritmo actual.',
    en: 'Drag the sliders. The calculator tells you how much you need and how many years are left at your current rate.',
  },
  outputLab: { es: 'Tu número de libertad', en: 'Your freedom number' },
  outputCtx: { es: '24 años a tu ritmo actual · 11 años con el sistema',
               en: '24 years at current pace · 11 years with the system' },
  s1: { es: 'Ingreso mensual neto', en: 'Net monthly income' },
  s2: { es: 'Ahorro mensual',       en: 'Monthly savings' },
  s3: { es: 'Edad objetivo',         en: 'Target retirement age' },
};

const D = {
  pill: { es: 'Diagnóstico · antes / después', en: 'Diagnostic · before / after' },
  headline: {
    es: <>Doce años trabajando. <span className="mint">Treinta días de colchón.</span></>,
    en: <>Twelve years working. <span className="mint">Thirty days of buffer.</span></>,
  },
  leftLab: { es: 'Lo que tenés hoy', en: 'What you have today' },
  rightLab: { es: 'Lo que tendrás con el sistema', en: 'What you\u2019ll have with the system' },
  m1l: { es: 'Saldo real', en: 'Real balance' },
  m2l: { es: 'Colchón en días', en: 'Buffer in days' },
  m3l: { es: 'Patrimonio neto Y20', en: 'Net worth Y20' },
  m1r: { es: 'Saldo real', en: 'Real balance' },
  m2r: { es: 'Colchón en días', en: 'Buffer in days' },
  m3r: { es: 'Patrimonio neto Y20', en: 'Net worth Y20' },
};

const E = {
  pill: { es: 'Portfolio Ledger · Posición 001', en: 'Portfolio Ledger · Position 001' },
  headlineA: { es: 'Valor declarado.', en: 'Declared value.' },
  headlineB: { es: 'Stack incluido.', en: 'Stack included.' },
  delta: { es: 'Delta · −86% · proporción 7.0×', en: 'Delta · −86% · 7.0× ratio' },
  rows: {
    es: [
      { id:'01', t:'Libro · The Money Command',                sub:'Manual operativo + 7 capítulos',     v:'USD 67.00' },
      { id:'02', t:'Bono · Cheat Sheet Negociación Salarial',  sub:'15 páginas, frameworks aplicables',  v:'USD 17.00' },
      { id:'03', t:'Bono · La Bóveda de Ingresos Pasivos',     sub:'Índice ejecutivo + setup por país',  v:'USD 17.00' },
      { id:'04', t:'Bono · Cartilla de Mentalidad y Metas',    sub:'Planner digital, opción imprimible', v:'USD 37.00' },
      { id:'05', t:'Bono · Atlas de Inversión Silenciosa',     sub:'ETFs + asignación con setup país',    v:'USD 27.00' },
      { id:'06', t:'App · The Money Command (lifetime · 500)', sub:'Dashboard 50/30/20 + número libertad', v:'USD 109.00' },
    ],
    en: [
      { id:'01', t:'Book · The Money Command',                sub:'Operating manual + 7 chapters',      v:'USD 67.00' },
      { id:'02', t:'Bonus · Salary Negotiation Cheat Sheet',  sub:'15 pages, applicable frameworks',    v:'USD 17.00' },
      { id:'03', t:'Bonus · Passive Income Vault',            sub:'Executive index + country setup',    v:'USD 17.00' },
      { id:'04', t:'Bonus · Mindset & Goals Workbook',        sub:'Digital planner, printable',         v:'USD 37.00' },
      { id:'05', t:'Bonus · Silent Investing Atlas',          sub:'ETFs + allocation w/ country setup', v:'USD 27.00' },
      { id:'06', t:'App · The Money Command (lifetime · 500)', sub:'50/30/20 dashboard + freedom #',     v:'USD 109.00' },
    ],
  },
  status: { es: 'Incluido', en: 'Included' },
};

/* ─────────────────────────────────────────────────────────────
   Reusable atoms
───────────────────────────────────────────────────────────── */

function TopBar({ lang }) {
  return (
    <div className="tmc-topbar">
      <div className="tmc-brand"><span className="dot" /> {COPY.brand}</div>
      <div className="tmc-status">
        <span><span className="led" />System Online</span>
        <span>{COPY.liveTag[lang]}</span>
        <span>Variante B</span>
      </div>
    </div>
  );
}

function FootBar({ lang }) {
  return (
    <div className="tmc-footbar">
      <span>{COPY.disclaimer[lang]}</span>
      <span>· · · 2026 · Variante B / 2 ·</span>
    </div>
  );
}

function PriceBlock({ lang, compact = false }) {
  return (
    <div className="price-block" style={compact ? { padding: '22px 26px' } : undefined}>
      <div className="head">{COPY.regularLabel[lang]}</div>
      <span className="strike"><span className="u">USD</span>47</span>
      <div className="now"><span className="n"><span className="u">USD</span>39</span></div>
      <div className="foot">
        <span className="lab">{COPY.founderCap[lang]}</span>
        <span className="rgt">{COPY.regularCap[lang]}</span>
      </div>
    </div>
  );
}

function CTA({ lang }) {
  return <button className="btn-mint">{COPY.primaryCta[lang]} <span className="arr">→</span></button>;
}

function CTAGhost({ lang }) {
  return <button className="btn-ghost">{COPY.secondaryCta[lang]} <span className="arr">→</span></button>;
}

/* ─────────────────────────────────────────────────────────────
   Hero A — "El dato es la métrica"
───────────────────────────────────────────────────────────── */

function HeroA({ lang }) {
  return (
    <div className="tmc tmc-hero">
      <div className="glow-tr" /><div className="glow-bl" />
      <div className="stage">
        <TopBar lang={lang} />

        <div style={{ flex: 1, display: 'grid', gridTemplateColumns: '1.4fr 1fr', gap: 56, alignItems: 'center', padding: '32px 0' }}>
          {/* LEFT — métrica */}
          <div>
            <span className="pill"><span className="led" />{A.pill[lang]}</span>
            <div className="display" style={{ fontSize: numS(320), color: 'var(--num-color, var(--accent))', letterSpacing: '-0.06em', lineHeight: 0.88, marginTop: 18, textShadow: '0 0 56px var(--num-glow, rgba(127,255,178,0.35))' }}>
              40<span style={{ fontSize: numS(200), marginLeft: -8, opacity: 0.92 }}>%</span>
            </div>
            <div className="display" style={{ fontSize: headS(32), color: 'var(--text)', letterSpacing: '-0.02em', lineHeight: 1.15, marginTop: 28, maxWidth: 620 }}>
              {A.body[lang]}
            </div>
            <div style={{ fontFamily: 'var(--mono)', fontSize: 11, color: 'var(--muted)', letterSpacing: '0.18em', textTransform: 'uppercase', marginTop: 22, paddingTop: 16, borderTop: '1px solid var(--border)', maxWidth: 540 }}>
              {A.source[lang]}
            </div>
          </div>

          {/* RIGHT — precio + CTA stack */}
          <div style={{ display: 'flex', flexDirection: 'column', gap: 20 }}>
            <PriceBlock lang={lang} />
            <CTA lang={lang} />
            <CTAGhost lang={lang} />
            <div style={{ display:'flex', justifyContent:'center', marginTop: 6 }}>
              <span className="pill gold"><span className="led" />{COPY.founderCounter[lang]}</span>
            </div>
            <div style={{ fontFamily: 'var(--mono)', fontSize: 11, color: 'var(--muted)', letterSpacing: '0.06em', lineHeight: 1.6, paddingTop: 14, borderTop: '1px solid var(--border)' }}>
              {A.subtitle[lang]}
            </div>
          </div>
        </div>

        <FootBar lang={lang} />
      </div>
    </div>
  );
}

/* ─────────────────────────────────────────────────────────────
   Hero B — "App como dashboard hero" (PRIORITY)
───────────────────────────────────────────────────────────── */

function MiniChart() {
  const bars = [];
  const cap = 22;
  for (let i = 0; i < 20; i++) {
    const interest = Math.pow(i / 19, 2.2) * 78;
    bars.push(<div className="bar-col" key={i}>
      <div className="seg k" style={{ height: cap + '%' }} />
      <div className="seg i" style={{ height: interest + '%' }} />
    </div>);
  }
  return (
    <div className="chart-wrap" style={{ height: 220 }}>
      <div className="y-axis"><span>$45k</span><span>$30k</span><span>$15k</span><span>$0</span></div>
      <div className="plot" style={{ height: '100%' }}>
        <div className="gridline" />
        {bars}
      </div>
      <div className="xlabels"><span>Now</span><span /><span>Y4</span><span /><span>Y8</span><span /><span>Y12</span><span /><span>Y16</span><span>Y20</span></div>
    </div>
  );
}

function Bar50_30_20({ lang }) {
  const segs = [
    { lab: lang==='es' ? 'Necesidades' : 'Needs',  pct: 48, c:'var(--accent2)' },
    { lab: lang==='es' ? 'Quiero'      : 'Wants',  pct: 28, c:'var(--accent)' },
    { lab: lang==='es' ? 'Invertir'    : 'Invest', pct: 24, c:'var(--gold)' },
  ];
  return (
    <div>
      <div style={{ display:'flex', justifyContent:'space-between', fontFamily:'var(--mono)', fontSize:10, letterSpacing:'0.2em', textTransform:'uppercase', color:'var(--muted)' }}>
        <span>{lang==='es' ? 'Asignación del mes' : 'Month allocation'}</span>
        <span>Target 50 · 30 · 20</span>
      </div>
      <div style={{ display:'flex', gap:4, marginTop:14, height:36 }}>
        {segs.map((s,i)=>(
          <div key={i} style={{ flex: s.pct, background:'rgba(255,255,255,0.02)', border:`1px solid ${s.c}`, borderRadius:6, position:'relative', display:'flex', alignItems:'center', padding:'0 10px' }}>
            <div style={{ position:'absolute', inset:0, background:s.c, opacity:0.12, borderRadius:5, pointerEvents:'none' }} />
            <span style={{ fontFamily:'var(--display)', fontWeight:700, fontSize:14, color:s.c, letterSpacing:'-0.01em', position:'relative' }}>{s.pct}%</span>
          </div>
        ))}
      </div>
      <div style={{ display:'flex', justifyContent:'space-between', marginTop:8, fontFamily:'var(--mono)', fontSize:10, color:'var(--muted)' }}>
        {segs.map((s,i)=>(<span key={i}>{s.lab}</span>))}
      </div>
    </div>
  );
}

function HeroB({ lang }) {
  return (
    <div className="tmc tmc-hero">
      <div className="glow-tr" /><div className="glow-bl" />
      <div className="stage">
        <TopBar lang={lang} />

        <div style={{ flex: 1, display: 'grid', gridTemplateColumns: '0.85fr 1.4fr', gap: 56, alignItems: 'center', padding: '32px 0' }}>
          {/* LEFT — copy */}
          <div>
            <span className="pill"><span className="led" />{B.pill[lang]}</span>
            <div className="display" style={{ fontSize: headS(88), letterSpacing: '-0.035em', lineHeight: 0.95, marginTop: 24 }}>
              {B.headlineA[lang]}<br/>
              <span className="mint">{B.headlineB[lang]}</span>
            </div>
            <p style={{ fontFamily:'var(--mono)', fontSize: 14, color: 'var(--text-2)', lineHeight: 1.65, marginTop: 24, maxWidth: 460 }}>
              {B.subtitle[lang]}
            </p>
            <div style={{ display:'flex', gap: 16, marginTop: 32, flexWrap:'wrap' }}>
              <CTA lang={lang} />
              <CTAGhost lang={lang} />
            </div>
            <div style={{ marginTop: 28, fontFamily:'var(--mono)', fontSize: 10, letterSpacing:'0.2em', textTransform:'uppercase', color:'var(--muted)' }}>
              <span style={{ color:'var(--accent)' }}>›</span> {COPY.founderCounter[lang]}
            </div>
          </div>

          {/* RIGHT — dashboard mockup */}
          <div style={{ position: 'relative' }}>
            <div className="card" style={{ padding: 24, borderRadius: 20 }}>
              <div style={{ display:'flex', justifyContent:'space-between', alignItems:'baseline', marginBottom: 18 }}>
                <div>
                  <div className="display" style={{ fontSize: 18, fontWeight: 700, letterSpacing:'-0.01em' }}>The Money Command App</div>
                  <div style={{ fontFamily:'var(--mono)', fontSize: 10, color:'var(--muted)', letterSpacing:'0.2em', textTransform:'uppercase', marginTop:6 }}>v1.0 · Compound · Mensual</div>
                </div>
                <span className="pill sky" style={{ padding:'5px 12px' }}><span className="led" />Live</span>
              </div>

              <div className="kpi-strip" style={{ marginBottom: 18 }}>
                <div className="ki k"><div className="lab">{lang==='es'?'Capital':'Capital'}</div><div className="num">$10,000</div><div className="ctx">{lang==='es'?'Depósito inicial':'Initial deposit'}</div></div>
                <div className="ki i"><div className="lab">{lang==='es'?'Interés':'Interest'}</div><div className="num">$30,387</div><div className="ctx">{B.chipA[lang]}</div></div>
                <div className="ki b"><div className="lab">{lang==='es'?'Balance final':'Final balance'}</div><div className="num">$40,387</div><div className="ctx">{B.chipB[lang]}</div></div>
              </div>

              <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center', marginBottom: 12 }}>
                <div className="display" style={{ fontSize: 14, fontWeight: 700 }}>Growth over time</div>
                <div style={{ display:'flex', gap:14, fontFamily:'var(--mono)', fontSize:10, color:'var(--muted)' }}>
                  <span><span style={{ display:'inline-block', width:8, height:8, background:'var(--accent2)', borderRadius:2, marginRight:6 }}/>Capital</span>
                  <span><span style={{ display:'inline-block', width:8, height:8, background:'var(--accent)', borderRadius:2, marginRight:6 }}/>Interest</span>
                </div>
              </div>

              <MiniChart />

              <div style={{ height: 1, background: 'var(--border)', margin: '18px 0' }} />

              <Bar50_30_20 lang={lang} />
            </div>

            {/* floating chips */}
            <div style={{ position:'absolute', top:-18, right:24 }}>
              <span className="pill gold" style={{ background:'var(--bg)', boxShadow:'0 0 20px rgba(0,0,0,0.6)' }}><span className="led" />{B.chipC[lang]}</span>
            </div>
            <div style={{ position:'absolute', bottom:-14, left:32 }}>
              <span className="pill sky" style={{ background:'var(--bg)', boxShadow:'0 0 20px rgba(0,0,0,0.6)' }}><span className="led" />Monarch $99/yr · YNAB $109/yr · {lang==='es'?'incluida':'included'}</span>
            </div>
          </div>
        </div>

        <FootBar lang={lang} />
      </div>
    </div>
  );
}

/* ─────────────────────────────────────────────────────────────
   Hero C — "Terminal interactivo"
───────────────────────────────────────────────────────────── */

function Slider({ label, value, unit='', tickL, tickR, fillPct }) {
  return (
    <div className="slider" style={{ marginBottom: 24 }}>
      <div className="lbl">
        <span>{label}</span>
        <span className="mint">[ INPUT ]</span>
      </div>
      <div className="val">{unit && <span className="u">{unit}</span>}{value}</div>
      <div className="track" style={{ background: `linear-gradient(to right, var(--accent) 0%, var(--accent) ${fillPct}%, rgba(255,255,255,0.08) ${fillPct}%, rgba(255,255,255,0.08) 100%)` }}>
        <div className="handle" style={{ left: fillPct + '%' }} />
      </div>
      <div className="ticks"><span>{tickL}</span><span>{tickR}</span></div>
    </div>
  );
}

function HeroC({ lang }) {
  return (
    <div className="tmc tmc-hero">
      <div className="glow-tr" /><div className="glow-bl" />
      <div className="stage">
        <TopBar lang={lang} />

        <div style={{ flex: 1, display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 56, alignItems: 'center', padding: '24px 0' }}>
          {/* LEFT — interactive calculator */}
          <div className="card top-mint" style={{ padding: 28 }}>
            <div style={{ display:'flex', justifyContent:'space-between', alignItems:'baseline', marginBottom: 24 }}>
              <span className="pill"><span className="led" />{C.pill[lang]}</span>
              <span style={{ fontFamily:'var(--mono)', fontSize:10, color:'var(--muted)', letterSpacing:'0.2em', textTransform:'uppercase' }}>v1.0</span>
            </div>

            <Slider label={C.s1[lang]} value="7,400" unit="$" tickL="$2k" tickR="$20k+" fillPct={42} />
            <Slider label={C.s2[lang]} value="1,400" unit="$" tickL="$0"  tickR="$5k+"  fillPct={28} />
            <Slider label={C.s3[lang]} value="55"   unit=""  tickL="40"   tickR="70"    fillPct={50} />

            <div style={{ borderTop: '1px solid var(--border)', marginTop: 8, paddingTop: 22 }}>
              <div style={{ display:'flex', justifyContent:'space-between', alignItems:'baseline' }}>
                <span style={{ fontFamily:'var(--mono)', fontSize:11, color:'var(--mint)', letterSpacing:'0.2em', textTransform:'uppercase' }}>{C.outputLab[lang]}</span>
                <span style={{ fontFamily:'var(--mono)', fontSize:10, color:'var(--muted)', letterSpacing:'0.15em', textTransform:'uppercase' }}>4% rule · CAGR 7%</span>
              </div>
              <div className="display" style={{ fontSize: numS(76), color:'var(--num-color, var(--accent))', letterSpacing:'-0.045em', lineHeight: 1, marginTop: 12, textShadow:'0 0 36px var(--num-glow, rgba(127,255,178,0.4))' }}>
                <span style={{ fontFamily:'var(--mono)', fontWeight:400, fontSize:24, color:'var(--num-color, var(--accent))', marginRight:8, opacity:0.8, verticalAlign:18 }}>USD</span>
                1,250,000
              </div>
              <div style={{ fontFamily:'var(--mono)', fontSize:12, color:'var(--text-2)', marginTop: 14, lineHeight: 1.6 }}>
                {C.outputCtx[lang]}
              </div>
            </div>
          </div>

          {/* RIGHT — copy & CTAs */}
          <div>
            <div className="display" style={{ fontSize: headS(76), letterSpacing: '-0.035em', lineHeight: 1.0 }}>
              {C.headlineA[lang]}<br/>
              <span className="mint">{C.headlineB[lang]}</span>
            </div>
            <p style={{ fontFamily:'var(--mono)', fontSize: 14, color: 'var(--text-2)', lineHeight: 1.65, marginTop: 24, maxWidth: 520 }}>
              {C.subtitle[lang]}
            </p>

            <div style={{ display:'flex', flexDirection:'column', gap: 14, marginTop: 36, alignItems:'flex-start' }}>
              <CTA lang={lang} />
              <CTAGhost lang={lang} />
            </div>

            <div style={{ marginTop: 32, paddingTop: 22, borderTop: '1px solid var(--border)' }}>
              <span className="pill gold"><span className="led" />{COPY.founderCounter[lang]}</span>
            </div>
          </div>
        </div>

        <FootBar lang={lang} />
      </div>
    </div>
  );
}

/* ─────────────────────────────────────────────────────────────
   Hero D — "Comparativa Robinhood-style"
───────────────────────────────────────────────────────────── */

function CompareCol({ tone, label, metrics, bars, lang }) {
  const isCoral = tone === 'coral';
  const c = isCoral ? 'var(--danger)' : 'var(--accent)';
  return (
    <div className={'card ' + (isCoral ? 'top-coral' : 'top-mint')} style={{ padding: 28, height: '100%' }}>
      <div style={{ display:'flex', justifyContent:'space-between', alignItems:'baseline', marginBottom: 20 }}>
        <span style={{ fontFamily:'var(--mono)', fontSize: 10, letterSpacing:'0.2em', textTransform:'uppercase', color: c }}>{label}</span>
        <span style={{ fontFamily:'var(--mono)', fontSize: 10, color:'var(--muted)', letterSpacing:'0.18em', textTransform:'uppercase' }}>{isCoral ? (lang==='es'?'Baseline · sin sistema':'Baseline · no system') : (lang==='es'?'Proyección · con sistema':'Projection · with system')}</span>
      </div>

      <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr 1fr', gap: 1, background:'var(--border)', borderRadius: 12, overflow:'hidden', marginBottom: 22 }}>
        {metrics.map((m,i) => (
          <div key={i} style={{ background:'var(--surface2)', padding:'14px 16px' }}>
            <div style={{ fontFamily:'var(--mono)', fontSize: 10, color:'var(--muted)', letterSpacing:'0.18em', textTransform:'uppercase' }}>{m.lab}</div>
            <div className="display" style={{ fontSize: numS(30), color: c, letterSpacing:'-0.03em', lineHeight: 1, marginTop: 10 }}>
              {m.unit && <span style={{ fontFamily:'var(--mono)', fontSize: 12, color:c, opacity:0.7, marginRight: 4, verticalAlign: 8 }}>{m.unit}</span>}
              {m.v}
            </div>
            <div style={{ fontFamily:'var(--mono)', fontSize: 10, color:'var(--muted)', marginTop: 6 }}>{m.sub}</div>
          </div>
        ))}
      </div>

      <div style={{ display:'flex', alignItems:'flex-end', gap: 4, height: 110, padding: '0 4px' }}>
        {bars.map((h, i) => (
          <div key={i} style={{
            flex: 1, height: h + '%',
            background: isCoral ? 'rgba(255,107,107,0.16)' : 'rgba(127,255,178,0.22)',
            border: '1px solid ' + c,
            borderBottom: 0,
            borderRadius: '2px 2px 0 0',
          }} />
        ))}
      </div>
      <div style={{ display:'flex', justifyContent:'space-between', marginTop: 10, fontFamily:'var(--mono)', fontSize: 10, color:'var(--muted)', letterSpacing:'0.04em' }}>
        <span>Y0</span><span>Y5</span><span>Y10</span><span>Y15</span><span>Y20</span>
      </div>
    </div>
  );
}

function HeroD({ lang }) {
  // Left: descending (paycheck-to-paycheck — colchón se erosiona)
  const barsL = [62, 52, 44, 32, 24, 18, 14, 10, 8, 6];
  // Right: ascending (con sistema)
  const barsR = [8, 14, 22, 32, 44, 58, 70, 82, 92, 100];

  const metricsL = [
    { lab: D.m1l[lang], v: '0',   unit: 'USD', sub: lang==='es' ? 'Ahorro real' : 'Real savings' },
    { lab: D.m2l[lang], v: '30',  unit: '',    sub: lang==='es' ? 'Antes del rojo' : 'Before red' },
    { lab: D.m3l[lang], v: '24K', unit: 'USD', sub: lang==='es' ? 'Sin compuesto' : 'No compounding' },
  ];
  const metricsR = [
    { lab: D.m1r[lang], v: '10K',  unit: 'USD', sub: lang==='es' ? 'Fondo activo' : 'Active fund' },
    { lab: D.m2r[lang], v: '180', unit: '',    sub: lang==='es' ? '6 meses · meta'  : '6 months · target' },
    { lab: D.m3r[lang], v: '404K', unit: 'USD', sub: lang==='es' ? 'CAGR 7% · 50/30/20' : 'CAGR 7% · 50/30/20' },
  ];

  return (
    <div className="tmc tmc-hero">
      <div className="glow-tr" /><div className="glow-bl" />
      <div className="stage">
        <TopBar lang={lang} />

        <div style={{ display:'flex', justifyContent:'space-between', alignItems:'flex-end', padding:'28px 0 24px' }}>
          <div>
            <span className="pill"><span className="led" />{D.pill[lang]}</span>
            <div className="display" style={{ fontSize: headS(64), letterSpacing:'-0.035em', lineHeight: 1.0, marginTop: 18, maxWidth: 900 }}>
              {D.headline[lang]}
            </div>
          </div>
          <div style={{ display:'flex', alignItems:'center', gap: 16 }}>
            <PriceBlock lang={lang} compact />
            <div style={{ display:'flex', flexDirection:'column', gap: 10 }}>
              <CTA lang={lang} />
              <CTAGhost lang={lang} />
            </div>
          </div>
        </div>

        <div style={{ flex: 1, display:'grid', gridTemplateColumns:'1fr 24px 1fr', gap: 0, alignItems:'stretch' }}>
          <CompareCol tone="coral" label={D.leftLab[lang]} metrics={metricsL} bars={barsL} lang={lang} />
          <div style={{ display:'flex', alignItems:'center', justifyContent:'center', color:'var(--muted)', fontFamily:'var(--mono)', fontSize: 12, letterSpacing:'0.2em', textTransform:'uppercase', writingMode:'vertical-rl', transform:'rotate(180deg)' }}>VS</div>
          <CompareCol tone="mint" label={D.rightLab[lang]} metrics={metricsR} bars={barsR} lang={lang} />
        </div>

        <FootBar lang={lang} />
      </div>
    </div>
  );
}

/* ─────────────────────────────────────────────────────────────
   Hero E — "Stack como dashboard"
───────────────────────────────────────────────────────────── */

function HeroE({ lang }) {
  const rows = E.rows[lang];
  return (
    <div className="tmc tmc-hero">
      <div className="glow-tr" /><div className="glow-bl" />
      <div className="stage">
        <TopBar lang={lang} />

        <div style={{ display:'flex', justifyContent:'space-between', alignItems:'flex-end', padding:'28px 0 28px' }}>
          <div>
            <span className="pill"><span className="led" />{E.pill[lang]}</span>
            <div className="display" style={{ fontSize: headS(72), letterSpacing:'-0.035em', lineHeight: 1.0, marginTop: 18 }}>
              {E.headlineA[lang]}<br/><span className="mint">{E.headlineB[lang]}</span>
            </div>
          </div>
          <div style={{ display:'flex', flexDirection:'column', alignItems:'flex-end', gap: 14 }}>
            <span className="pill gold"><span className="led" />{COPY.founderCounter[lang]}</span>
            <CTA lang={lang} />
          </div>
        </div>

        <div className="card top-mint" style={{ flex: 1, padding: '28px 32px', display:'flex', flexDirection:'column' }}>
          {/* table head */}
          <div style={{ display:'grid', gridTemplateColumns:'40px 1fr 140px 130px', gap: 18, padding:'0 0 12px', borderBottom:'1px solid var(--border)', fontFamily:'var(--mono)', fontSize: 10, letterSpacing:'0.2em', textTransform:'uppercase', color:'var(--muted)' }}>
            <span>#</span>
            <span>{lang==='es' ? 'Posición' : 'Position'}</span>
            <span style={{ textAlign:'right' }}>{lang==='es' ? 'Valor mercado' : 'Market value'}</span>
            <span style={{ textAlign:'right' }}>Status</span>
          </div>
          {rows.map((r, i) => (
            <div key={r.id} style={{ display:'grid', gridTemplateColumns:'40px 1fr 140px 130px', gap: 18, padding:'16px 0', borderBottom: i < rows.length-1 ? '1px solid var(--border)' : 'none', alignItems:'center' }}>
              <span style={{ fontFamily:'var(--mono)', fontSize: 11, color:'var(--accent)' }}>{r.id}</span>
              <span>
                <div className="display" style={{ fontSize: 17, fontWeight: 600, letterSpacing:'-0.005em' }}>{r.t}</div>
                <div style={{ fontFamily:'var(--mono)', fontSize: 11, color:'var(--muted)', marginTop: 4 }}>{r.sub}</div>
              </span>
              <span style={{ fontFamily:'var(--mono)', fontSize: 14, color:'var(--text-2)', textAlign:'right' }}>{r.v}</span>
              <span style={{ display:'flex', justifyContent:'flex-end' }}>
                <span style={{ fontFamily:'var(--mono)', fontSize: 10, letterSpacing:'0.2em', color:'var(--accent)', textTransform:'uppercase', padding:'5px 12px', border:'1px solid rgba(127,255,178,0.3)', borderRadius: 100, minWidth: 100, textAlign:'center' }}>{E.status[lang]}</span>
              </span>
            </div>
          ))}

          {/* total bar */}
          <div style={{ marginTop: 16, height: 4, background: 'var(--surface2)', borderRadius: 2, overflow: 'hidden', position: 'relative' }}>
            <div style={{ position:'absolute', left:0, top:0, bottom:0, width:'24.5%', background:'var(--accent)' }} />
            <div style={{ position:'absolute', left:'24.5%', top:0, bottom:0, width:'6.2%', background:'var(--accent2)' }} />
            <div style={{ position:'absolute', left:'30.7%', top:0, bottom:0, width:'13.5%', background:'var(--gold)' }} />
            <div style={{ position:'absolute', left:'44.2%', top:0, bottom:0, width:'9.9%', background:'var(--danger)' }} />
          </div>

          {/* total row */}
          <div style={{ marginTop: 18, display:'grid', gridTemplateColumns:'1fr auto auto', gap: 28, alignItems:'center' }}>
            <div>
              <div style={{ fontFamily:'var(--mono)', fontSize: 10, color:'var(--muted)', letterSpacing:'0.2em', textTransform:'uppercase' }}>{E.delta[lang]}</div>
              <div style={{ fontFamily:'var(--mono)', fontSize: 10, color:'var(--muted)', marginTop: 6, letterSpacing:'0.15em', textTransform:'uppercase' }}>Settlement <span className="mint">T+0</span> · {lang==='es' ? 'acceso inmediato' : 'instant access'}</div>
            </div>
            <div className="display" style={{ fontSize: numS(36), fontWeight: 700, color:'var(--muted)', letterSpacing:'-0.03em', position:'relative' }}>
              <span style={{ fontFamily:'var(--mono)', fontSize: 13, marginRight: 6, color:'var(--muted)' }}>USD</span>274
              <span style={{ position:'absolute', left:-4, right:-4, top:'56%', height:1, background:'var(--accent)' }} />
            </div>
            <div className="display" style={{ fontSize: numS(72), fontWeight: 800, color:'var(--num-color, var(--accent))', letterSpacing:'-0.045em', lineHeight: 1, textShadow:'0 0 30px var(--num-glow, rgba(127,255,178,0.3))' }}>
              <span style={{ fontFamily:'var(--mono)', fontSize: 18, marginRight: 8, color:'var(--num-color, var(--accent))' }}>USD</span>39
            </div>
          </div>
        </div>

        <FootBar lang={lang} />
      </div>
    </div>
  );
}

/* ─────────────────────────────────────────────────────────────
   App
───────────────────────────────────────────────────────────── */

const W = 1440;
const H = 860;

function App() {
  const [t, setTweak] = window.useTweaks(TWEAK_DEFAULTS);

  React.useEffect(() => {
    const r = document.documentElement.style;
    r.setProperty('--num-scale', String(t.numScale));
    r.setProperty('--head-scale', String(t.headScale));
    // Headline reframe highlight — the "manifestar / es estructura" second part.
    r.setProperty('--hl', t.highlight === 'Cyan' ? '#4dd9ff' : '#7fffb2');
    // Big hero numerals (40%, freedom number, USD 39 total).
    const numCol = t.numberColor === 'Cyan' ? '#4dd9ff' : '#7fffb2';
    r.setProperty('--num-color', numCol);
    const glowRgb = t.numberColor === 'Cyan' ? '77,217,255' : '127,255,178';
    r.setProperty('--num-glow', `rgba(${glowRgb},0.4)`);
    // Cyan glow orb intensity (bottom-left atmosphere).
    r.setProperty('--cyan-glow', String(t.cyanGlow));
  }, [t]);

  const {
    TweaksPanel, TweakSection, TweakSlider, TweakRadio,
  } = window;

  return (
    <React.Fragment>
      <DesignCanvas>
        <DCSection id="dir-a" title="Dirección A · El dato es la métrica" subtitle="40% como héroe absoluto · pricing lateral">
          <DCArtboard id="a-es" label="ES" width={W} height={H}><HeroA lang="es" /></DCArtboard>
          <DCArtboard id="a-en" label="EN" width={W} height={H}><HeroA lang="en" /></DCArtboard>
        </DCSection>

        <DCSection id="dir-b" title="Dirección B · App como dashboard (PRIORITY)" subtitle="Dashboard hero · titular condensado · chips flotantes">
          <DCArtboard id="b-es" label="ES" width={W} height={H}><HeroB lang="es" /></DCArtboard>
          <DCArtboard id="b-en" label="EN" width={W} height={H}><HeroB lang="en" /></DCArtboard>
        </DCSection>

        <DCSection id="dir-c" title="Dirección C · Terminal interactivo" subtitle="Calculadora del número de libertad embebida en el hero">
          <DCArtboard id="c-es" label="ES" width={W} height={H}><HeroC lang="es" /></DCArtboard>
          <DCArtboard id="c-en" label="EN" width={W} height={H}><HeroC lang="en" /></DCArtboard>
        </DCSection>

        <DCSection id="dir-d" title="Dirección D · Comparativa Robinhood-style" subtitle="Hoy (coral, descendente) vs sistema (mint, ascendente)">
          <DCArtboard id="d-es" label="ES" width={W} height={H}><HeroD lang="es" /></DCArtboard>
          <DCArtboard id="d-en" label="EN" width={W} height={H}><HeroD lang="en" /></DCArtboard>
        </DCSection>

        <DCSection id="dir-e" title="Dirección E · Stack como portfolio" subtitle="Valor declarado en tabla tipo ledger fintech">
          <DCArtboard id="e-es" label="ES" width={W} height={H}><HeroE lang="es" /></DCArtboard>
          <DCArtboard id="e-en" label="EN" width={W} height={H}><HeroE lang="en" /></DCArtboard>
        </DCSection>
      </DesignCanvas>

      <TweaksPanel title="Tweaks">
        <TweakSection label="Escala" />
        <TweakSlider label="Tamaño de números" value={t.numScale} min={0.55} max={1.1} step={0.01}
                     onChange={(v) => setTweak('numScale', v)} />
        <TweakSlider label="Tamaño de titulares" value={t.headScale} min={0.6} max={1.1} step={0.01}
                     onChange={(v) => setTweak('headScale', v)} />

        <TweakSection label="Cyan" />
        <TweakRadio label="Resalte del titular" value={t.highlight}
                    options={['Mint', 'Cyan']}
                    onChange={(v) => setTweak('highlight', v)} />
        <TweakRadio label="Números héroe" value={t.numberColor}
                    options={['Mint', 'Cyan']}
                    onChange={(v) => setTweak('numberColor', v)} />
        <TweakSlider label="Glow cyan de fondo" value={t.cyanGlow} min={0} max={0.22} step={0.01}
                     onChange={(v) => setTweak('cyanGlow', v)} />
      </TweaksPanel>
    </React.Fragment>
  );
}

ReactDOM.createRoot(document.getElementById('root')).render(<App />);
